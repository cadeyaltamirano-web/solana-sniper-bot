// Main JavaScript for PumpFun Sniper Bot

// Mobile Navigation Toggle
const navToggle = document.getElementById('nav-toggle');
const navMenu = document.getElementById('nav-menu');

if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        
        // Animate hamburger bars
        const bars = navToggle.querySelectorAll('.bar');
        bars.forEach((bar, index) => {
            if (navMenu.classList.contains('active')) {
                if (index === 0) bar.style.transform = 'rotate(-45deg) translate(-5px, 6px)';
                if (index === 1) bar.style.opacity = '0';
                if (index === 2) bar.style.transform = 'rotate(45deg) translate(-5px, -6px)';
            } else {
                if (index === 0) bar.style.transform = 'none';
                if (index === 1) bar.style.opacity = '1';
                if (index === 2) bar.style.transform = 'none';
            }
        });
    });
}

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        if (navMenu && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            const bars = navToggle.querySelectorAll('.bar');
            bars.forEach((bar, index) => {
                if (index === 0) bar.style.transform = 'none';
                if (index === 1) bar.style.opacity = '1';
                if (index === 2) bar.style.transform = 'none';
            });
        }
    });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const offsetTop = target.offsetTop - 70; // Account for fixed navbar
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Bot Settings Form Functionality
const form = document.getElementById('botSettingsForm');
const saveButton = document.getElementById('saveSettings');

// Form elements
const minAmount = document.getElementById('minAmount');
const maxAmount = document.getElementById('maxAmount');
const slippage = document.getElementById('slippage');
const takeProfit = document.getElementById('takeProfit');
const stopLoss = document.getElementById('stopLoss');
const maxDevHold = document.getElementById('maxDevHold');
const autoSell = document.getElementById('autoSell');

// Preview elements
const previewRange = document.getElementById('previewRange');
const previewRisk = document.getElementById('previewRisk');
const previewSlippage = document.getElementById('previewSlippage');
const previewProfit = document.getElementById('previewProfit');
const previewLoss = document.getElementById('previewLoss');

// Update preview when form values change
function updatePreview() {
    if (minAmount && maxAmount && previewRange) {
        const min = minAmount.value || '0.1';
        const max = maxAmount.value || '1.0';
        previewRange.textContent = `${min} - ${max} SOL`;
    }
    
    if (slippage && previewSlippage) {
        const slippageValue = slippage.value || '5';
        previewSlippage.textContent = `${slippageValue}%`;
    }
    
    if (takeProfit && previewProfit) {
        const profitValue = takeProfit.value || '50';
        previewProfit.textContent = `+${profitValue}%`;
    }
    
    if (stopLoss && previewLoss) {
        const lossValue = stopLoss.value || '30';
        previewLoss.textContent = `-${lossValue}%`;
    }
    
    // Calculate risk level
    if (previewRisk) {
        const slippageVal = parseFloat(slippage?.value || '5');
        const stopLossVal = parseFloat(stopLoss?.value || '30');
        
        let riskLevel = 'Low';
        if (slippageVal > 10 || stopLossVal > 40) {
            riskLevel = 'High';
        } else if (slippageVal > 5 || stopLossVal > 25) {
            riskLevel = 'Moderate';
        }
        
        previewRisk.textContent = riskLevel;
        previewRisk.className = `value ${riskLevel.toLowerCase()}`;
    }
}

// Add event listeners to form inputs
[minAmount, maxAmount, slippage, takeProfit, stopLoss, maxDevHold, autoSell].forEach(element => {
    if (element) {
        element.addEventListener('input', updatePreview);
        element.addEventListener('change', updatePreview);
    }
});

// Auto-sell toggle functionality
if (autoSell) {
    autoSell.addEventListener('change', function() {
        if (this.checked) {
            // Set default values when auto-sell is enabled
            if (minAmount) minAmount.value = minAmount.value || '0.1';
            if (maxAmount) maxAmount.value = maxAmount.value || '0.2';
            if (slippage) slippage.value = slippage.value || '5';
            if (takeProfit) takeProfit.value = takeProfit.value || '30';
            if (stopLoss) stopLoss.value = stopLoss.value || '10';
            if (maxDevHold) maxDevHold.value = maxDevHold.value || '30';
            updatePreview();
        }
    });
}

// Save settings functionality
if (saveButton) {
    saveButton.addEventListener('click', function() {
        const settings = {
            minAmount: minAmount?.value,
            maxAmount: maxAmount?.value,
            slippage: slippage?.value,
            takeProfit: takeProfit?.value,
            stopLoss: stopLoss?.value,
            maxDevHold: maxDevHold?.value,
            autoSell: autoSell?.checked
        };
        
        // Store in localStorage
        localStorage.setItem('botSettings', JSON.stringify(settings));
        
        // Show success message
        showNotification('Settings saved successfully!', 'success');
    });
}

// Load saved settings
function loadSettings() {
    const saved = localStorage.getItem('botSettings');
    if (saved) {
        try {
            const settings = JSON.parse(saved);
            if (minAmount && settings.minAmount) minAmount.value = settings.minAmount;
            if (maxAmount && settings.maxAmount) maxAmount.value = settings.maxAmount;
            if (slippage && settings.slippage) slippage.value = settings.slippage;
            if (takeProfit && settings.takeProfit) takeProfit.value = settings.takeProfit;
            if (stopLoss && settings.stopLoss) stopLoss.value = settings.stopLoss;
            if (maxDevHold && settings.maxDevHold) maxDevHold.value = settings.maxDevHold;
            if (autoSell && settings.autoSell !== undefined) autoSell.checked = settings.autoSell;
            updatePreview();
        } catch (error) {
            console.error('Error loading saved settings:', error);
        }
    }
}

// Initialize preview and load saved settings
document.addEventListener('DOMContentLoaded', function() {
    updatePreview();
    loadSettings();
});

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add notification styles if not already present
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 20px;
                background: var(--surface);
                border: 1px solid var(--border);
                border-radius: var(--radius-md);
                padding: var(--space-md);
                box-shadow: var(--shadow-xl);
                z-index: 10000;
                animation: slideInRight 0.3s ease;
                max-width: 300px;
            }
            .notification-success {
                border-left: 4px solid var(--success);
            }
            .notification-error {
                border-left: 4px solid var(--error);
            }
            .notification-info {
                border-left: 4px solid var(--primary);
            }
            .notification-content {
                display: flex;
                align-items: center;
                gap: var(--space-sm);
                color: var(--text-primary);
            }
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Scroll animations
function handleScrollAnimations() {
    const elements = document.querySelectorAll('.feature-card');
    const windowHeight = window.innerHeight;
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < windowHeight - elementVisible) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
}

// Initialize scroll animations
document.addEventListener('DOMContentLoaded', function() {
    const elements = document.querySelectorAll('.feature-card');
    elements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });
    
    handleScrollAnimations();
});

window.addEventListener('scroll', handleScrollAnimations);

// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(10, 10, 15, 0.98)';
            navbar.style.backdropFilter = 'blur(20px)';
        } else {
            navbar.style.background = 'rgba(10, 10, 15, 0.95)';
            navbar.style.backdropFilter = 'blur(20px)';
        }
    }
});


// Reviews Carousel Functionality
class ReviewsCarousel {
    constructor() {
        this.track = document.getElementById('reviewsTrack');
        this.dotsContainer = document.getElementById('carouselDots');
        this.currentIndex = 0;
        this.cardsToShow = this.getCardsToShow();
        this.autoPlayInterval = null;
        this.resizeTimeout = null;
        
        if (this.track) {
            this.init();
        }
    }
    
    getCardsToShow() {
        if (window.innerWidth < 768) return 1;
        if (window.innerWidth < 1200) return 2;
        return 3;
    }
    
    init() {
        this.cards = Array.from(this.track.children);
        this.totalCards = this.cards.length;
        this.maxIndex = Math.max(0, this.totalCards - this.cardsToShow);
        
        // Create dots
        this.createDots();
        
        // Initial update
        setTimeout(() => {
            this.updateCarousel();
        }, 100);
        
        // Start autoplay
        this.startAutoPlay();
        
        // Handle window resize with debounce
        window.addEventListener('resize', () => {
            clearTimeout(this.resizeTimeout);
            this.resizeTimeout = setTimeout(() => {
                const oldCardsToShow = this.cardsToShow;
                this.cardsToShow = this.getCardsToShow();
                
                if (oldCardsToShow !== this.cardsToShow) {
                    this.maxIndex = Math.max(0, this.totalCards - this.cardsToShow);
                    this.currentIndex = Math.min(this.currentIndex, this.maxIndex);
                    this.createDots();
                }
                
                this.updateCarousel();
            }, 250);
        });
        
        // Pause on hover (desktop only)
        if (this.track && window.innerWidth > 768) {
            this.track.addEventListener('mouseenter', () => this.stopAutoPlay());
            this.track.addEventListener('mouseleave', () => this.startAutoPlay());
        }
    }
    
    createDots() {
        if (!this.dotsContainer) return;
        
        this.dotsContainer.innerHTML = '';
        
        for (let i = 0; i <= this.maxIndex; i++) {
            const dot = document.createElement('div');
            dot.className = 'carousel-dot';
            if (i === this.currentIndex) dot.classList.add('active');
            
            dot.addEventListener('click', () => {
                this.currentIndex = i;
                this.updateCarousel();
                this.stopAutoPlay();
                this.startAutoPlay(); // Restart autoplay after manual interaction
            });
            
            this.dotsContainer.appendChild(dot);
        }
    }
    
    updateCarousel() {
        if (!this.track || !this.cards.length) return;
        
        // Calculate card width including gap
        const cardWidth = this.cards[0].offsetWidth;
        const computedStyle = window.getComputedStyle(this.track);
        const gap = parseFloat(computedStyle.gap) || 24;
        
        const offset = -(this.currentIndex * (cardWidth + gap));
        
        this.track.style.transform = `translateX(${offset}px)`;
        
        // Update dots
        const dots = this.dotsContainer?.querySelectorAll('.carousel-dot');
        if (dots) {
            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === this.currentIndex);
            });
        }
    }
    
    next() {
        this.currentIndex = (this.currentIndex + 1) > this.maxIndex ? 0 : this.currentIndex + 1;
        this.updateCarousel();
    }
    
    prev() {
        this.currentIndex = (this.currentIndex - 1) < 0 ? this.maxIndex : this.currentIndex - 1;
        this.updateCarousel();
    }
    
    startAutoPlay() {
        this.stopAutoPlay(); // Clear any existing interval
        this.autoPlayInterval = setInterval(() => {
            this.next();
        }, 5000); // Change review every 5 seconds
    }
    
    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
}

// Initialize carousel when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const reviewsCarousel = new ReviewsCarousel();
});
