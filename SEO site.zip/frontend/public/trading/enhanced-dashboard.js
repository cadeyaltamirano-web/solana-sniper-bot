// Enhanced Trading Dashboard JavaScript with Real-time WebSocket Integration

class EnhancedTradingBot {
    constructor() {
        // Core state
        this.isConnected = false;
        this.isRunning = false;
        this.isPreviewMode = true;
        this.walletAddress = null;
        this.walletBalance = 0;
        this.tokens = [];
        this.sessionId = 1;
        this.chart = null;
        
        // WebSocket for real-time data
        this.ws = null;
        this.wsReconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.wsHeartbeatInterval = null;
        
        // Pump.fun API integration
        this.pumpfunTokens = [];
        this.pumpfunTokenDetails = [];
        this.lastTokenFetch = 0;
        this.tokenFetchInterval = 5000; // Default 5 seconds
        this.tokenMetadataCache = new Map();
        
        // Speed settings
        this.speedSettings = {
            fast: 2000,    // 2 seconds
            normal: 5000,  // 5 seconds
            conservative: 15000 // 15 seconds
        };
        this.currentSpeed = 'normal';
        
        // Statistics
        this.stats = {
            totalTrades: 0,
            successfulTrades: 0,
            totalProfit: 0,
            bestTrade: 0,
            dayProfitLoss: 0
        };
        
        // Settings
        this.settings = {
            minAmount: 0.1,
            maxAmount: 1.0,
            slippage: 5,
            takeProfit: 50,
            stopLoss: 30,
            maxDevHold: 30,
            tradingSpeed: 'normal',
            maxHoldTime: 30,
            honeypotDetection: true,
            rugPullProtection: true,
            aiAnalysis: true,
            smartEntry: true,
            riskTolerance: 'medium'
        };
        
        // Intervals
        this.tokenGenerationInterval = null;
        this.statusUpdateInterval = null;
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateUI();
        this.initChart();
        this.loadTheme();
        this.loadSettings();
        this.startStatusAnimation();
        this.showEmptyState();
        
        // Initialize WebSocket connection for real-time data
        this.initWebSocket();
        
        // Initialize Pump.fun API integration (fallback)
        this.initPumpfunAPI();
        
        console.log('Enhanced Trading Bot initialized with real-time WebSocket');
    }

    // WebSocket Real-time Integration
    initWebSocket() {
        try {
            const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${wsProtocol}//${window.location.host}/ws/tokens`;
            
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('WebSocket connected to real-time token stream');
                this.wsReconnectAttempts = 0;
                this.updatePumpfunStatus('connected', 'Real-time connection active');
                this.showNotification('✅ Connected to real-time token stream!', 'success');
                
                // Start heartbeat
                this.startWebSocketHeartbeat();
            };
            
            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleWebSocketMessage(data);
                } catch (error) {
                    console.error('Error parsing WebSocket message:', error);
                }
            };
            
            this.ws.onclose = () => {
                console.log('WebSocket connection closed');
                this.updatePumpfunStatus('disconnected', 'Real-time connection lost');
                this.stopWebSocketHeartbeat();
                this.attemptWebSocketReconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.updatePumpfunStatus('error', 'Connection error');
            };
            
        } catch (error) {
            console.error('Failed to initialize WebSocket:', error);
            this.updatePumpfunStatus('error', 'WebSocket initialization failed');
            // Fallback to HTTP polling
            this.initPumpfunAPI();
        }
    }
    
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'connected':
                console.log('WebSocket handshake completed');
                break;
                
            case 'new_token':
                // Handle new token from real-time stream
                if (this.isRunning) {
                    console.log(`New token received via WebSocket: ${data.name} (${data.mint})`);
                    this.processRealTimeToken(data);
                }
                break;
                
            case 'pong':
                // Heartbeat response
                console.log('WebSocket heartbeat confirmed');
                break;
                
            case 'settings_updated':
                console.log('Settings updated on server');
                break;
                
            default:
                console.log('Unknown WebSocket message type:', data.type);
        }
    }
    
    processRealTimeToken(tokenData) {
        // Create enhanced token object from real-time data
        const enhancedToken = this.createEnhancedTokenFromWebSocket(tokenData);
        
        // Add to tokens array
        this.tokens.unshift(enhancedToken);
        
        // Process trading logic if bot is running
        if (this.isRunning) {
            setTimeout(() => this.processTokenTrade(enhancedToken), 500);
        }
        
        // Update UI
        this.hideEmptyState();
        this.hideLoadingIndicator();
        this.renderTokens();
        
        // Show notification for new token
        this.showNotification(`🚀 New token detected: ${enhancedToken.name}`, 'info');
    }
    
    createEnhancedTokenFromWebSocket(wsData) {
        const now = new Date();
        return {
            id: Date.now() + Math.random(),
            name: wsData.name || `Token ${wsData.mint.slice(0, 8)}`,
            symbol: wsData.symbol || 'NEW',
            address: wsData.mint,
            time: now.toLocaleTimeString(),
            status: 'detected',
            amount: '0.000 SOL',
            profit: 0,
            successRate: Math.floor(Math.random() * 30) + 60, // 60-90% range
            riskLevel: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
            marketCap: Math.random() * 100000 + 10000,
            liquidity: Math.random() * 50000 + 5000,
            volume24h: Math.random() * 25000,
            holders: Math.floor(Math.random() * 500) + 50,
            devWalletPercent: Math.floor(Math.random() * 40) + 10,
            contractVerified: Math.random() > 0.3,
            liquidityLocked: Math.random() > 0.4,
            socialMedia: Math.random() > 0.5,
            burnedTokens: Math.floor(Math.random() * 50),
            createdAgo: Math.floor(Math.random() * 300) + 30,
            icon: wsData.symbol ? wsData.symbol[0] : '🪙',
            image: null,
            description: `Real-time token from pump.fun`,
            isReal: true // Mark as real token from WebSocket
        };
    }
    
    startWebSocketHeartbeat() {
        this.wsHeartbeatInterval = setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                    type: 'ping',
                    timestamp: new Date().toISOString()
                }));
            }
        }, 30000); // Every 30 seconds
    }
    
    stopWebSocketHeartbeat() {
        if (this.wsHeartbeatInterval) {
            clearInterval(this.wsHeartbeatInterval);
            this.wsHeartbeatInterval = null;
        }
    }
    
    attemptWebSocketReconnect() {
        if (this.wsReconnectAttempts < this.maxReconnectAttempts) {
            this.wsReconnectAttempts++;
            console.log(`Attempting WebSocket reconnection... (${this.wsReconnectAttempts}/${this.maxReconnectAttempts})`);
            
            setTimeout(() => {
                this.initWebSocket();
            }, Math.pow(2, this.wsReconnectAttempts) * 1000); // Exponential backoff
        } else {
            console.log('Max WebSocket reconnection attempts reached, falling back to HTTP polling');
            this.updatePumpfunStatus('disconnected', 'Using HTTP fallback');
            this.initPumpfunAPI();
        }
    }
    
    // Speed control methods
    setTradingSpeed(speed) {
        this.currentSpeed = speed;
        this.tokenFetchInterval = this.speedSettings[speed];
        this.settings.tradingSpeed = speed;
        
        // Update WebSocket with new settings
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'settings',
                settings: {
                    speed: speed,
                    interval: this.tokenFetchInterval
                }
            }));
        }
        
        // Restart token generation with new speed if running
        if (this.isRunning) {
            this.startTokenGeneration();
        }
        
        this.showNotification(`Trading speed set to ${speed.toUpperCase()}`, 'info');
        console.log(`Trading speed changed to ${speed} (${this.tokenFetchInterval}ms)`);
    }

    // Pump.fun API Integration (HTTP Fallback)
    async initPumpfunAPI() {
        this.updatePumpfunStatus('connecting', 'Connecting to Pump.fun API...');
        
        try {
            console.log('Initializing Pump.fun HTTP API fallback...');
            await this.fetchNewTokensFromPumpfun();
            
            if (this.pumpfunTokens.length > 0) {
                this.updatePumpfunStatus('connected', `Connected to Pump.fun API (${this.pumpfunTokens.length} tokens)`);
                this.showNotification('✅ Connected to Pump.fun API! Displaying real tokens.', 'success');
            } else {
                this.updatePumpfunStatus('disconnected', 'No new tokens found on Pump.fun');
                this.showNotification('⚠️ Pump.fun API connected but no new tokens found', 'warning');
            }
        } catch (error) {
            console.error('Failed to initialize Pump.fun API:', error);
            this.updatePumpfunStatus('disconnected', 'Failed to connect to Pump.fun API');
            this.showNotification('❌ Unable to connect to Pump.fun API - check connection', 'error');
        }
    }

    updatePumpfunStatus(status, text) {
        const statusDot = document.getElementById('pumpfunStatusDot');
        const statusText = document.getElementById('pumpfunStatusText');
        
        if (statusDot && statusText) {
            statusDot.className = `status-dot ${status}`;
            statusText.textContent = text;
        }
    }

    async fetchNewTokensFromPumpfun() {
        try {
            // Get backend URL from environment
            const backendUrl = process.env.REACT_APP_BACKEND_URL || '';
            
            // Use enhanced API with fast mode for speed
            const response = await fetch(`${backendUrl}/api/pumpfun/new-tokens?limit=10&fast_mode=true`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            
            if (data && data.mint && Array.isArray(data.mint)) {
                this.pumpfunTokens = data.mint;
                this.lastTokenFetch = Date.now();
                console.log(`Fetched ${this.pumpfunTokens.length} new tokens from Pump.fun via enhanced API (${data.source})`);
                
                // Store token details for later use
                if (data.tokens && Array.isArray(data.tokens)) {
                    this.pumpfunTokenDetails = data.tokens;
                }
            } else if (data && data.error) {
                console.warn('API returned error:', data.error);
                this.pumpfunTokens = [];
                this.pumpfunTokenDetails = [];
            } else {
                throw new Error('Invalid response format from backend API');
            }
        } catch (error) {
            console.error('Error fetching tokens from backend API:', error);
            this.pumpfunTokens = [];
            this.pumpfunTokenDetails = [];
            this.showNotification('❌ Unable to fetch real tokens from Pump.fun - check connection', 'error');
        }
    }

    async getTokenMetadata(tokenAddress) {
        // Check cache first
        if (this.tokenMetadataCache.has(tokenAddress)) {
            return this.tokenMetadataCache.get(tokenAddress);
        }

        // Check if we have token details from the API call
        if (this.pumpfunTokenDetails && Array.isArray(this.pumpfunTokenDetails)) {
            const tokenDetail = this.pumpfunTokenDetails.find(token => token.mint === tokenAddress);
            if (tokenDetail) {
                // Get IPFS metadata if available
                if (tokenDetail.metadata) {
                    try {
                        const metadataResponse = await fetch(tokenDetail.metadata);
                        if (metadataResponse.ok) {
                            const ipfsData = await metadataResponse.json();
                            const metadata = {
                                name: ipfsData.name || tokenDetail.name || 'Unknown Token',
                                symbol: ipfsData.symbol || tokenDetail.symbol || 'UNKNOWN',
                                description: ipfsData.description || '',
                                image: ipfsData.image || null,
                                address: tokenAddress,
                                decimals: 6,
                                currentSupply: 0
                            };
                            this.tokenMetadataCache.set(tokenAddress, metadata);
                            return metadata;
                        }
                    } catch (error) {
                        console.warn('Failed to fetch IPFS metadata:', error);
                    }
                }
                
                // Fallback to basic token data
                const metadata = {
                    name: tokenDetail.name || 'Unknown Token',
                    symbol: tokenDetail.symbol || 'UNKNOWN',
                    description: '',
                    image: null,
                    address: tokenAddress,
                    decimals: 6,
                    currentSupply: 0
                };
                this.tokenMetadataCache.set(tokenAddress, metadata);
                return metadata;
            }
        }

        // Fallback to API call for metadata
        try {
            const backendUrl = process.env.REACT_APP_BACKEND_URL || '';
            const response = await fetch(`${backendUrl}/api/pumpfun/token-metadata/${tokenAddress}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.result) {
                    this.tokenMetadataCache.set(tokenAddress, data.result);
                    return data.result;
                }
            }
        } catch (error) {
            console.warn('Failed to fetch token metadata from API:', error);
        }

        // Final fallback
        const fallbackMetadata = {
            name: `Token ${tokenAddress.slice(0, 8)}`,
            symbol: 'UNKNOWN',
            description: 'Token metadata unavailable',
            image: null,
            address: tokenAddress,
            decimals: 6,
            currentSupply: 0
        };
        this.tokenMetadataCache.set(tokenAddress, fallbackMetadata);
        return fallbackMetadata;
    }

    // Bot Control Methods
    async startBot() {
        if (this.isRunning) return;
        
        // Sync quick settings before starting
        this.syncQuickSettings();
        
        this.isRunning = true;
        this.updateBotStatus();
        
        // Clear existing tokens for fresh start
        this.tokens = [];
        this.renderTokens();
        
        this.hideEmptyState();
        this.showLoadingIndicator();
        
        // Start token generation
        this.startTokenGeneration();
        
        this.showNotification('🤖 Trading bot started! Monitoring for new tokens...', 'success');
        console.log('Trading bot started with settings:', this.settings);
    }

    stopBot() {
        if (!this.isRunning) return;
        
        this.isRunning = false;
        this.updateBotStatus();
        
        // Stop token generation
        if (this.tokenGenerationInterval) {
            clearInterval(this.tokenGenerationInterval);
            this.tokenGenerationInterval = null;
        }
        
        this.hideLoadingIndicator();
        
        if (this.tokens.length === 0) {
            this.showEmptyState();
        }
        
        this.showNotification('⏹️ Trading bot stopped', 'info');
        console.log('Trading bot stopped');
    }

    updateBotStatus() {
        const statusBadge = document.getElementById('botStatus').querySelector('.status-badge');
        const startBtn = document.getElementById('startBotBtn');
        const stopBtn = document.getElementById('stopBotBtn');
        
        if (this.isRunning) {
            statusBadge.className = 'status-badge running';
            statusBadge.textContent = 'RUNNING';
            startBtn.disabled = true;
            stopBtn.disabled = false;
        } else {
            statusBadge.className = 'status-badge stopped';
            statusBadge.textContent = 'STOPPED';
            startBtn.disabled = false;
            stopBtn.disabled = true;
        }
    }

    // Token Generation and Processing
    startTokenGeneration() {
        // Clear existing interval
        if (this.tokenGenerationInterval) {
            clearInterval(this.tokenGenerationInterval);
        }
        
        if (!this.isRunning) return;
        
        // Use current speed setting
        const interval = this.speedSettings[this.currentSpeed] || this.tokenFetchInterval;
        
        console.log(`Starting token generation with ${interval}ms interval (${this.currentSpeed} mode)`);
        
        // Start generating tokens at the specified interval
        this.tokenGenerationInterval = setInterval(() => {
            if (this.isRunning) {
                this.addNewToken();
            }
        }, interval);
        
        // Add first token immediately
        setTimeout(() => {
            if (this.isRunning) {
                this.addNewToken();
            }
        }, 1000);
    }

    async addNewToken() {
        if (!this.isRunning) return;
        
        try {
            // Try to get real token from our collection
            let tokenData = null;
            
            if (this.pumpfunTokens.length > 0) {
                // Use real token from pump.fun
                const randomIndex = Math.floor(Math.random() * this.pumpfunTokens.length);
                const tokenAddress = this.pumpfunTokens[randomIndex];
                
                // Get metadata for this token
                const metadata = await this.getTokenMetadata(tokenAddress);
                tokenData = {
                    name: metadata.name,
                    symbol: metadata.symbol,
                    address: tokenAddress,
                    description: metadata.description,
                    image: metadata.image,
                    isReal: true
                };
            } else {
                // Fallback to simulated token
                tokenData = {
                    name: this.generateRandomTokenName(),
                    symbol: this.generateRandomSymbol(),
                    address: this.generateRandomAddress(),
                    description: 'Simulated token - API unavailable',
                    image: null,
                    isReal: false
                };
            }
            
            // Create enhanced token object
            const token = this.createEnhancedToken(tokenData);
            
            // Add to beginning of tokens array
            this.tokens.unshift(token);
            
            // Remove old tokens to prevent memory issues (keep last 50)
            if (this.tokens.length > 50) {
                this.tokens = this.tokens.slice(0, 50);
            }
            
            // Process trading logic
            setTimeout(() => this.processTokenTrade(token), 500);
            
            // Update UI
            this.hideEmptyState();
            this.hideLoadingIndicator();
            this.renderTokens();
            
        } catch (error) {
            console.error('Error adding new token:', error);
        }
    }

    createEnhancedToken(tokenData) {
        const now = new Date();
        return {
            id: Date.now() + Math.random(),
            name: tokenData.name,
            symbol: tokenData.symbol,
            address: tokenData.address,
            time: now.toLocaleTimeString(),
            status: 'detected',
            amount: '0.000 SOL',
            profit: 0,
            successRate: Math.floor(Math.random() * 30) + 60, // 60-90% range
            riskLevel: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
            marketCap: Math.random() * 100000 + 10000,
            liquidity: Math.random() * 50000 + 5000,
            volume24h: Math.random() * 25000,
            holders: Math.floor(Math.random() * 500) + 50,
            devWalletPercent: Math.floor(Math.random() * 40) + 10,
            contractVerified: Math.random() > 0.3,
            liquidityLocked: Math.random() > 0.4,
            socialMedia: Math.random() > 0.5,
            burnedTokens: Math.floor(Math.random() * 50),
            createdAgo: Math.floor(Math.random() * 300) + 30,
            icon: tokenData.symbol ? tokenData.symbol[0] : '🪙',
            image: tokenData.image,
            description: tokenData.description,
            isReal: tokenData.isReal || false
        };
    }

    generateRandomTokenName() {
        const prefixes = ['Moon', 'Rocket', 'Diamond', 'Golden', 'Super', 'Mega', 'Ultra', 'Hyper', 'Turbo', 'Crypto'];
        const suffixes = ['Coin', 'Token', 'Cash', 'Finance', 'Protocol', 'Network', 'Chain', 'Swap', 'Vault', 'Labs'];
        return prefixes[Math.floor(Math.random() * prefixes.length)] + 
               suffixes[Math.floor(Math.random() * suffixes.length)];
    }

    generateRandomSymbol() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let result = '';
        for (let i = 0; i < Math.floor(Math.random() * 3) + 3; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    generateRandomAddress() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < 44; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    async processTokenTrade(token) {
        if (!this.isRunning) return;
        
        // Update token status to analyzing
        token.status = 'analyzing';
        this.renderTokens();
        
        // Simulate analysis time (0.5-2 seconds)
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1500 + 500));
        if (!this.isRunning) return;
        
        // Perform advanced filtering
        const filterResult = this.performAdvancedFiltering(token);
        if (filterResult.skip) {
            token.status = filterResult.reason;
            this.renderTokens();
            return;
        }
        
        // Make trade decision
        const shouldTrade = this.makeTradeDecision(token);
        if (!shouldTrade) {
            token.status = 'skipped';
            this.renderTokens();
            return;
        }
        
        // Calculate optimal buy amount
        const amount = this.calculateOptimalBuyAmount(token);
        token.amount = `${amount.toFixed(3)} SOL`;
        
        // Execute simulated buy
        token.status = 'buying';
        this.renderTokens();
        
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 300)); // 0.3-1.3s buy time
        if (!this.isRunning) return;
        
        token.status = 'bought';
        this.stats.totalTrades++;
        this.renderTokens();
        this.updateStats();
        
        // Calculate holding time
        const holdingTime = this.calculateHoldingTime(token);
        
        // Simulate holding period with potential early exit
        const checkInterval = Math.min(holdingTime / 10, 2000); // Check every 10% of holding time or 2s max
        let elapsedTime = 0;
        
        const holdingCheck = setInterval(() => {
            if (!this.isRunning) {
                clearInterval(holdingCheck);
                return;
            }
            
            elapsedTime += checkInterval;
            const progressRatio = elapsedTime / holdingTime;
            
            // Check for early exit
            if (this.shouldExitEarly(token, progressRatio)) {
                clearInterval(holdingCheck);
                this.executeSell(token, amount, 'early_exit');
                return;
            }
            
            // Check if holding time is complete
            if (elapsedTime >= holdingTime) {
                clearInterval(holdingCheck);
                this.executeSell(token, amount, 'hold_complete');
            }
        }, checkInterval);
    }

    async executeSell(token, amount, reason) {
        if (!this.isRunning) return;
        
        // Make exit decision
        const exitDecision = this.makeExitDecision(token);
        
        if (exitDecision.shouldExit) {
            token.status = 'selling';
            this.renderTokens();
            
            await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 300)); // 0.3-1.3s sell time
            if (!this.isRunning) return;
            
            token.status = 'sold';
            
            // Calculate realistic profit/loss
            const profitResult = this.calculateRealisticProfit(token, amount, exitDecision.reason);
            token.profit = profitResult.profit;
            
            if (profitResult.profit > 0) {
                this.stats.successfulTrades++;
                this.stats.totalProfit += profitResult.profit;
                
                if (profitResult.profit > this.stats.bestTrade) {
                    this.stats.bestTrade = profitResult.profit;
                }
            } else {
                this.stats.totalProfit += profitResult.profit; // Add negative value
            }
            
            this.stats.dayProfitLoss = this.stats.totalProfit;
            this.renderTokens();
            this.updateStats();
            this.updateChart();
        } else {
            // Continue holding
            token.status = 'long_hold';
            this.renderTokens();
        }
    }

    performAdvancedFiltering(token) {
        // Honeypot detection (enhanced)
        if (this.settings.honeypotDetection) {
            const honeypotRisk = this.calculateHoneypotRisk(token);
            if (Math.random() < honeypotRisk) {
                return { skip: true, reason: 'honeypot_detected' };
            }
        }

        // Rug pull detection (enhanced)
        if (this.settings.rugPullProtection) {
            const rugRisk = this.calculateRugPullRisk(token);
            if (Math.random() < rugRisk) {
                return { skip: true, reason: 'rug_risk_high' };
            }
        }

        // Low liquidity filter
        if (token.liquidity < 10000) { // Less than $10K liquidity
            if (Math.random() < 0.7) { // 70% chance to skip low liquidity
                return { skip: true, reason: 'liquidity_low' };
            }
        }

        // Dev wallet concentration filter
        if (token.devWalletPercent > 30) { // More than 30% dev holding
            if (Math.random() < 0.6) { // 60% chance to skip
                return { skip: true, reason: 'dev_concentration' };
            }
        }

        return { skip: false };
    }

    calculateHoneypotRisk(token) {
        let risk = 0.02; // Base 2% honeypot risk
        
        // Increase risk based on factors
        if (!token.contractVerified) risk += 0.03;
        if (token.devWalletPercent > 40) risk += 0.04;
        if (token.liquidity < 5000) risk += 0.03;
        if (token.createdAgo < 60) risk += 0.02; // Very new token
        
        return Math.min(risk, 0.15); // Max 15% risk
    }

    calculateRugPullRisk(token) {
        let risk = 0.01; // Base 1% rug risk
        
        // Increase risk based on factors
        if (!token.liquidityLocked) risk += 0.05;
        if (!token.socialMedia) risk += 0.02;
        if (token.devWalletPercent > 35) risk += 0.04;
        if (token.burnedTokens < 10) risk += 0.02;
        
        return Math.min(risk, 0.12); // Max 12% risk
    }

    makeTradeDecision(token) {
        let tradeScore = 0.5; // Base 50% chance to trade
        
        // Positive factors
        if (token.riskLevel === 'low') tradeScore += 0.3;
        else if (token.riskLevel === 'medium') tradeScore += 0.1;
        else tradeScore -= 0.2; // High risk
        
        if (token.contractVerified) tradeScore += 0.1;
        if (token.liquidityLocked) tradeScore += 0.15;
        if (token.socialMedia) tradeScore += 0.05;
        if (token.volume24h > token.marketCap * 0.1) tradeScore += 0.1; // Good volume
        
        // Settings-based adjustments
        if (this.settings.aiAnalysis) tradeScore += 0.1;
        if (this.settings.smartEntry) tradeScore += 0.05;
        
        // Risk tolerance adjustment
        switch (this.settings.riskTolerance) {
            case 'low': tradeScore -= 0.1; break;
            case 'high': tradeScore += 0.15; break;
        }
        
        return Math.random() < Math.min(tradeScore, 0.95); // Max 95% trade chance
    }

    calculateOptimalBuyAmount(token) {
        let baseAmount = Math.random() * (this.settings.maxAmount - this.settings.minAmount) + this.settings.minAmount;
        
        // Adjust based on token quality
        if (token.riskLevel === 'low') {
            baseAmount *= 1.2; // Invest more in low-risk tokens
        } else if (token.riskLevel === 'high') {
            baseAmount *= 0.7; // Invest less in high-risk tokens
        }
        
        // Adjust based on liquidity
        const liquidityRatio = token.liquidity / token.marketCap;
        if (liquidityRatio < 0.1) {
            baseAmount *= 0.8; // Reduce amount for low liquidity
        }
        
        return Math.min(baseAmount, this.settings.maxAmount);
    }

    calculateHoldingTime(token) {
        let baseTime = Math.random() * this.settings.maxHoldTime * 60 * 1000; // Convert to ms
        
        // Adjust based on token characteristics
        if (token.riskLevel === 'high') {
            baseTime *= 0.5; // Hold high-risk tokens for shorter time
        } else if (token.riskLevel === 'low') {
            baseTime *= 1.5; // Hold low-risk tokens longer
        }
        
        // For demo purposes, limit to max 15 seconds
        return Math.min(baseTime, 15000);
    }

    shouldExitEarly(token, progressRatio) {
        // Check for early exit conditions based on simulated price movement
        const currentPriceChange = (Math.random() - 0.5) * 100 * progressRatio; // Simulate price change
        
        // Take profit early if hitting target
        if (currentPriceChange > this.settings.takeProfit * 0.8) {
            return Math.random() < 0.7; // 70% chance to take profit early
        }
        
        // Stop loss early if dropping significantly
        if (currentPriceChange < -this.settings.stopLoss * 0.6) {
            return Math.random() < 0.8; // 80% chance to cut losses early
        }
        
        return false;
    }

    makeExitDecision(token) {
        // Simulate market conditions and decide whether to sell
        const marketCondition = Math.random();
        
        if (marketCondition < 0.1) {
            return { shouldExit: false, reason: 'holding' }; // 10% chance to continue holding
        }
        
        return { shouldExit: true, reason: 'target_reached' };
    }

    calculateRealisticProfit(token, amount, exitReason) {
        let successChance = this.calculateSuccessChance(token);
        const isProfit = Math.random() < successChance;
        
        if (isProfit) {
            // Calculate profit based on token quality and market conditions
            let multiplier = Math.random() * (this.settings.takeProfit / 100);
            
            // Bonus for good tokens
            if (token.riskLevel === 'low') multiplier *= 1.3;
            if (token.contractVerified) multiplier *= 1.1;
            if (token.liquidityLocked) multiplier *= 1.1;
            
            const profit = +(amount * multiplier).toFixed(4);
            return { profit, isProfit: true };
        } else {
            // Calculate loss
            let multiplier = Math.random() * (this.settings.stopLoss / 100);
            
            // Higher losses for risky tokens
            if (token.riskLevel === 'high') multiplier *= 1.2;
            if (!token.contractVerified) multiplier *= 1.1;
            
            const loss = -(amount * multiplier).toFixed(4);
            return { profit: +loss, isProfit: false };
        }
    }

    calculateSuccessChance(token) {
        let successChance = 0.6; // Base 60% success rate
        
        // Token quality adjustments
        if (token.riskLevel === 'low') successChance += 0.25;
        else if (token.riskLevel === 'medium') successChance += 0.1;
        else successChance -= 0.15; // High risk penalty
        
        if (token.contractVerified) successChance += 0.1;
        if (token.liquidityLocked) successChance += 0.15;
        if (token.socialMedia) successChance += 0.05;
        
        // Settings adjustments
        if (this.settings.aiAnalysis) successChance += 0.12;
        if (this.settings.smartEntry) successChance += 0.08;
        if (this.settings.rugPullProtection) successChance += 0.05;
        if (this.settings.honeypotDetection) successChance += 0.05;
        
        // Risk tolerance adjustment
        switch (this.settings.riskTolerance) {
            case 'low': successChance += 0.1; break;
            case 'high': successChance -= 0.05; break;
        }
        
        return Math.min(successChance, 0.9); // Cap at 90%
    }

    renderTokens() {
        const tokenList = document.getElementById('tokenList');
        tokenList.innerHTML = '';

        if (this.tokens.length === 0) {
            return;
        }

        this.tokens.forEach((token, index) => {
            const tokenElement = document.createElement('div');
            tokenElement.className = 'token-item';
            tokenElement.style.animationDelay = `${index * 0.05}s`;
            
            const profitClass = token.profit > 0 ? 'positive' : token.profit < 0 ? 'negative' : '';
            const profitText = token.profit !== 0 ? 
                `${token.profit > 0 ? '+' : ''}${token.profit} SOL` : '0.000 SOL';

            // Determine status badge class and text
            let statusClass = token.status;
            let statusText = token.status.toUpperCase();
            
            if (token.status === 'honeypot_detected') {
                statusClass = 'error';
                statusText = 'HONEYPOT';
            } else if (token.status === 'rug_risk_high') {
                statusClass = 'error';
                statusText = 'RUG RISK';
            } else if (token.status === 'liquidity_low') {
                statusClass = 'warning';
                statusText = 'LOW LIQUIDITY';
            } else if (token.status === 'dev_concentration') {
                statusClass = 'warning';
                statusText = 'HIGH DEV %';
            }

            tokenElement.innerHTML = `
                <div class="token-info">
                    <div class="token-icon">
                        ${token.image ? 
                            `<img src="${token.image}" alt="${token.name}" class="token-image" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                             <div class="token-icon-fallback" style="display:none;">${token.icon || token.symbol[0]}</div>` :
                            `<div class="token-icon-text">${token.icon || token.symbol[0]}</div>`
                        }
                        ${token.isReal ? 
                            '<div class="real-token-badge" title="Real token from Pump.fun">🟢 LIVE</div>' : 
                            '<div class="sim-token-badge" title="Simulated token">🔶 SIM</div>'
                        }
                    </div>
                    <div class="token-details">
                        <span class="token-name" title="${token.description || token.name}">${token.name}</span>
                        <span class="token-symbol">${token.symbol}</span>
                        ${token.address ? `<span class="token-address" title="${token.address}">${token.address.slice(0, 8)}...</span>` : ''}
                    </div>
                </div>
                <div class="token-time">${token.time}</div>
                <div class="token-status">
                    <span class="status-badge ${statusClass}">${statusText}</span>
                </div>
                <div class="token-amount">${token.amount}</div>
                <div class="token-profit ${profitClass}">${profitText}</div>
                <div class="token-success-rate">${token.successRate}%</div>
                <div class="token-actions">
                    ${this.isPreviewMode ? '' : `
                        <button class="action-btn view" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${token.status === 'bought' ? 
                            '<button class="action-btn sell" title="Force Sell"><i class="fas fa-times"></i></button>' : 
                            ''
                        }
                    `}
                </div>
            `;

            tokenList.appendChild(tokenElement);
        });
    }

    filterTokens(filter) {
        const tokenItems = document.querySelectorAll('.token-item');
        
        tokenItems.forEach(item => {
            const profitElement = item.querySelector('.token-profit');
            const isProfit = profitElement.classList.contains('positive');
            const isLoss = profitElement.classList.contains('negative');
            
            let show = true;
            
            switch(filter) {
                case 'profitable':
                    show = isProfit;
                    break;
                case 'losses':
                    show = isLoss;
                    break;
                case 'all':
                default:
                    show = true;
                    break;
            }
            
            item.style.display = show ? 'grid' : 'none';
        });
    }

    async refreshTokens() {
        const btn = document.getElementById('refreshTokens');
        btn.style.transform = 'rotate(180deg) scale(1.1)';
        
        // Refresh Pump.fun data
        try {
            await this.fetchNewTokensFromPumpfun();
            if (this.pumpfunTokens.length > 0) {
                this.showNotification(`Refreshed: Got ${this.pumpfunTokens.length} real tokens from Pump.fun!`, 'success');
                this.updatePumpfunStatus('connected', `Connected to Pump.fun (${this.pumpfunTokens.length} tokens)`);
            } else {
                this.showNotification('Refreshed but no new tokens found on Pump.fun', 'warning');
                this.updatePumpfunStatus('disconnected', 'No new tokens on Pump.fun');
            }
        } catch (error) {
            console.error('Error refreshing Pump.fun data:', error);
            this.showNotification('Error refreshing Pump.fun data', 'error');
            this.updatePumpfunStatus('disconnected', 'Connection error to Pump.fun');
        }
        
        setTimeout(() => {
            btn.style.transform = '';
            
            // Add a few new tokens if bot is running and we have real tokens
            if (this.isRunning && this.pumpfunTokens.length > 0) {
                for (let i = 0; i < 3; i++) {
                    setTimeout(() => this.addNewToken(), i * 500);
                }
            }
        }, 500);
    }

    // UI State Management
    updateUI() {
        const btn = document.getElementById('walletConnectBtn');
        if (!btn) {
            console.error('Wallet connect button not found');
            return;
        }
        
        const btnTitle = document.getElementById('walletStatus');
        const btnSubtitle = btn.querySelector('.btn-subtitle');
        const walletInfo = document.getElementById('walletInfo');
        const walletAddress = document.getElementById('walletAddress');
        const walletBalance = document.getElementById('walletBalance');

        if (this.isConnected) {
            btn.classList.add('connected');
            btn.classList.remove('connecting');
            if (btnTitle) btnTitle.textContent = 'Connected';
            if (btnSubtitle) btnSubtitle.textContent = 'Click to disconnect';
            
            if (walletInfo) walletInfo.style.display = 'block';
            if (walletAddress && this.walletAddress) {
                walletAddress.textContent = `${this.walletAddress.slice(0, 8)}...${this.walletAddress.slice(-8)}`;
            }
            if (walletBalance) {
                walletBalance.textContent = `${this.walletBalance} SOL`;
            }
        } else {
            btn.classList.remove('connected', 'connecting');
            if (btnTitle) btnTitle.textContent = 'Connect Wallet';
            if (btnSubtitle) btnSubtitle.textContent = 'Click to connect';
            
            if (walletInfo) walletInfo.style.display = 'none';
        }

        this.updateBotStatus();
        this.syncUISettings();
    }

    syncUISettings() {
        // Sync quick settings with current settings
        const quickMinAmount = document.getElementById('quickMinAmount');
        const quickMaxAmount = document.getElementById('quickMaxAmount');
        const quickTakeProfit = document.getElementById('quickTakeProfit');
        const quickStopLoss = document.getElementById('quickStopLoss');
        
        if (quickMinAmount) quickMinAmount.value = this.settings.minAmount;
        if (quickMaxAmount) quickMaxAmount.value = this.settings.maxAmount;
        if (quickTakeProfit) quickTakeProfit.value = this.settings.takeProfit;
        if (quickStopLoss) quickStopLoss.value = this.settings.stopLoss;
    }

    syncQuickSettings() {
        // Sync quick settings to main settings
        const minAmount = parseFloat(document.getElementById('quickMinAmount').value);
        const maxAmount = parseFloat(document.getElementById('quickMaxAmount').value);
        const takeProfit = parseFloat(document.getElementById('quickTakeProfit').value);
        const stopLoss = parseFloat(document.getElementById('quickStopLoss').value);

        if (minAmount && minAmount > 0) this.settings.minAmount = minAmount;
        if (maxAmount && maxAmount > 0) this.settings.maxAmount = maxAmount;
        if (takeProfit && takeProfit > 0) this.settings.takeProfit = takeProfit;
        if (stopLoss && stopLoss > 0) this.settings.stopLoss = stopLoss;

        this.saveSettingsToStorage();
    }

    showPreviewMode() {
        document.getElementById('previewMode').style.display = 'flex';
        document.getElementById('actionsHeader').style.display = 'none';
    }

    hidePreviewMode() {
        document.getElementById('previewMode').style.display = 'none';
        document.getElementById('actionsHeader').style.display = 'block';
    }

    showEmptyState() {
        document.getElementById('emptyState').style.display = 'flex';
        document.getElementById('tokenList').style.display = 'none';
    }

    hideEmptyState() {
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('tokenList').style.display = 'block';
    }

    showLoadingIndicator() {
        document.getElementById('loadingIndicator').style.display = 'flex';
    }

    hideLoadingIndicator() {
        document.getElementById('loadingIndicator').style.display = 'none';
    }

    // Statistics and Chart
    updateStats() {
        document.getElementById('totalTrades').textContent = this.stats.totalTrades;
        document.getElementById('successfulTrades').textContent = this.stats.successfulTrades;
        
        const winRate = this.stats.totalTrades > 0 ? 
            Math.round((this.stats.successfulTrades / this.stats.totalTrades) * 100) : 0;
        document.getElementById('winRate').textContent = `${winRate}%`;
        
        document.getElementById('totalProfit').textContent = `${this.stats.totalProfit.toFixed(3)} SOL`;
        document.getElementById('dayProfitLoss').textContent = 
            `${this.stats.dayProfitLoss >= 0 ? '+' : ''}${this.stats.dayProfitLoss.toFixed(3)} SOL`;
        document.getElementById('bestTrade').textContent = `+${this.stats.bestTrade.toFixed(3)} SOL`;
        
        // Update profit/loss colors
        const dayPLElement = document.getElementById('dayProfitLoss');
        dayPLElement.className = `value ${this.stats.dayProfitLoss >= 0 ? 'positive' : 'negative'}`;
    }

    initChart() {
        const ctx = document.getElementById('profitChart');
        if (!ctx) return;
        
        // Check if Chart.js is available
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js is not loaded');
            return;
        }
        
        // eslint-disable-next-line no-undef
        this.chart = new Chart(ctx.getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Profit/Loss',
                    data: [],
                    borderColor: '#00ff88',
                    backgroundColor: 'rgba(0, 255, 136, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(26, 26, 36, 0.9)',
                        titleColor: '#ffffff',
                        bodyColor: '#a8a8b3',
                        borderColor: '#00ff88',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        display: false,
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        display: false,
                        grid: {
                            display: false
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });

        // Initialize with some demo data
        this.initChartData();
    }

    initChartData() {
        if (!this.chart) return;
        
        const dataPoints = 20;
        let cumulative = 0;
        
        for (let i = 0; i < dataPoints; i++) {
            const change = (Math.random() - 0.45) * 0.5; // Slight positive bias
            cumulative += change;
            
            this.chart.data.labels.push('');
            this.chart.data.datasets[0].data.push(cumulative);
        }
        
        this.chart.update('none');
    }

    updateChart() {
        if (!this.chart) return;
        
        const data = this.chart.data.datasets[0].data;
        const newValue = this.stats.totalProfit;
        
        data.push(newValue);
        this.chart.data.labels.push('');
        
        if (data.length > 50) {
            data.shift();
            this.chart.data.labels.shift();
        }
        
        // Update chart color based on overall performance
        const color = this.stats.totalProfit >= 0 ? '#00ff88' : '#ef4444';
        this.chart.data.datasets[0].borderColor = color;
        this.chart.data.datasets[0].backgroundColor = color.replace(')', ', 0.1)').replace('rgb', 'rgba');
        
        this.chart.update('none');
    }

    updateChartPeriod(period) {
        // This would typically fetch different data based on period
        // For demo purposes, we'll just update the chart title
        console.log(`Chart updated to ${period} period`);
        this.showNotification(`Chart period changed to ${period}`, 'info');
    }

    // Settings Management
    showSettingsModal() {
        document.getElementById('settingsModal').classList.add('active');
        this.loadCurrentSettings();
    }

    hideSettingsModal() {
        document.getElementById('settingsModal').classList.remove('active');
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    loadCurrentSettings() {
        // Load settings into modal forms
        document.getElementById('settingsMinAmount').value = this.settings.minAmount;
        document.getElementById('settingsMaxAmount').value = this.settings.maxAmount;
        document.getElementById('settingsSlippage').value = this.settings.slippage;
        document.getElementById('settingsTakeProfit').value = this.settings.takeProfit;
        document.getElementById('settingsStopLoss').value = this.settings.stopLoss;
        document.getElementById('settingsMaxDevHold').value = this.settings.maxDevHold;
        document.getElementById('honeypotDetection').checked = this.settings.honeypotDetection;
        document.getElementById('rugPullProtection').checked = this.settings.rugPullProtection;
        document.getElementById('tradingSpeed').value = this.settings.tradingSpeed;
        document.getElementById('maxHoldTime').value = this.settings.maxHoldTime;
        document.getElementById('aiAnalysis').checked = this.settings.aiAnalysis;
        document.getElementById('smartEntry').checked = this.settings.smartEntry;
        document.getElementById('riskTolerance').value = this.settings.riskTolerance;
    }

    saveSettings() {
        // Save settings from modal forms
        this.settings = {
            minAmount: parseFloat(document.getElementById('settingsMinAmount').value),
            maxAmount: parseFloat(document.getElementById('settingsMaxAmount').value),
            slippage: parseFloat(document.getElementById('settingsSlippage').value),
            takeProfit: parseFloat(document.getElementById('settingsTakeProfit').value),
            stopLoss: parseFloat(document.getElementById('settingsStopLoss').value),
            maxDevHold: parseInt(document.getElementById('settingsMaxDevHold').value),
            honeypotDetection: document.getElementById('honeypotDetection').checked,
            rugPullProtection: document.getElementById('rugPullProtection').checked,
            tradingSpeed: document.getElementById('tradingSpeed').value,
            maxHoldTime: parseInt(document.getElementById('maxHoldTime').value),
            aiAnalysis: document.getElementById('aiAnalysis').checked,
            smartEntry: document.getElementById('smartEntry').checked,
            riskTolerance: document.getElementById('riskTolerance').value
        };

        // Update current speed based on settings
        this.setTradingSpeed(this.settings.tradingSpeed);

        this.saveSettingsToStorage();
        this.syncUISettings();
        this.hideSettingsModal();
        this.showNotification('Settings saved successfully!', 'success');
        
        // Restart token generation with new settings if running
        if (this.isRunning) {
            this.startTokenGeneration();
        }
    }

    saveSettingsToStorage() {
        localStorage.setItem('enhancedBotSettings', JSON.stringify(this.settings));
    }

    loadSettings() {
        const saved = localStorage.getItem('enhancedBotSettings');
        if (saved) {
            this.settings = { ...this.settings, ...JSON.parse(saved) };
            this.setTradingSpeed(this.settings.tradingSpeed);
        }
    }

    // Theme Management
    loadTheme() {
        const savedTheme = localStorage.getItem('selectedTheme') || 'theme1';
        this.changeTheme(savedTheme);
        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.value = savedTheme;
        }
    }

    changeTheme(themeName) {
        document.documentElement.className = themeName;
        localStorage.setItem('selectedTheme', themeName);
        this.showNotification(`Theme changed to ${this.getThemeName(themeName)}`, 'info');
    }

    getThemeName(themeId) {
        const themeNames = {
            theme1: 'Dark Cyber',
            theme2: 'Matrix Green',
            theme3: 'Purple Haze',
            theme4: 'Golden Sun',
            theme5: 'Blood Red',
            theme6: 'Ice Blue',
            theme7: 'Ocean Teal',
            theme8: 'Sunset Orange'
        };
        return themeNames[themeId] || 'Unknown Theme';
    }

    // Wallet Connection Simulation
    async connectWallet(walletType) {
        this.hideWalletModal();
        
        // Show connecting state
        const btn = document.getElementById('walletConnectBtn');
        const btnTitle = document.getElementById('walletStatus');
        const btnSubtitle = btn.querySelector('.btn-subtitle');
        
        btn.classList.add('connecting');
        if (btnTitle) btnTitle.textContent = 'Connecting...';
        if (btnSubtitle) btnSubtitle.textContent = 'Please wait';
        
        this.showNotification(`Connecting to ${walletType} wallet...`, 'info');
        
        // Simulate connection delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Simulate connection success
        this.isConnected = true;
        this.isPreviewMode = false;
        this.walletAddress = this.generateRandomAddress();
        this.walletBalance = (Math.random() * 10 + 1).toFixed(3); // 1-11 SOL
        
        this.updateUI();
        this.hidePreviewMode();
        
        this.showNotification(`✅ Successfully connected to ${walletType} wallet!`, 'success');
        console.log(`Connected to ${walletType} wallet:`, this.walletAddress);
    }

    disconnectWallet() {
        this.isConnected = false;
        this.isPreviewMode = true;
        this.walletAddress = null;
        this.walletBalance = 0;
        
        // Stop bot if running
        if (this.isRunning) {
            this.stopBot();
        }
        
        this.updateUI();
        this.showPreviewMode();
        
        this.showNotification('Wallet disconnected', 'info');
        console.log('Wallet disconnected');
    }

    // Modal Management
    showWalletModal() {
        document.getElementById('walletModal').classList.add('active');
    }

    hideWalletModal() {
        document.getElementById('walletModal').classList.remove('active');
    }

    // Utility Methods
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        // Add to body
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => notification.classList.add('show'), 100);
        
        // Auto hide after 5 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
        
        // Manual close
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        });
    }

    startStatusAnimation() {
        let dots = 0;
        this.statusUpdateInterval = setInterval(() => {
            const statusText = document.getElementById('statusText');
            if (statusText && !this.isConnected) {
                dots = (dots + 1) % 4;
                statusText.textContent = 'INITIALIZING' + '.'.repeat(dots);
            }
        }, 500);
    }

    // Event Binding
    bindEvents() {
        // Wallet connection
        document.getElementById('walletConnectBtn').addEventListener('click', () => {
            if (this.isConnected) {
                this.disconnectWallet();
            } else {
                this.showWalletModal();
            }
        });

        // Wallet modal events
        document.getElementById('closeModal').addEventListener('click', () => {
            this.hideWalletModal();
        });

        // Wallet selection
        document.querySelectorAll('.wallet-option').forEach(option => {
            option.addEventListener('click', () => {
                const walletType = option.dataset.wallet;
                this.connectWallet(walletType);
            });
        });

        // Bot control
        document.getElementById('startBotBtn').addEventListener('click', () => {
            this.startBot();
        });

        document.getElementById('stopBotBtn').addEventListener('click', () => {
            this.stopBot();
        });

        document.getElementById('startFromEmpty').addEventListener('click', () => {
            this.startBot();
        });

        // Settings
        document.getElementById('settingsBtn').addEventListener('click', () => {
            this.showSettingsModal();
        });

        document.getElementById('advancedSettingsBtn').addEventListener('click', () => {
            this.showSettingsModal();
        });

        document.getElementById('closeSettingsModal').addEventListener('click', () => {
            this.hideSettingsModal();
        });

        document.getElementById('cancelSettings').addEventListener('click', () => {
            this.hideSettingsModal();
        });

        document.getElementById('saveSettings').addEventListener('click', () => {
            this.saveSettings();
        });

        // Settings tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tabName = btn.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // Quick settings inputs
        document.querySelectorAll('#quickMinAmount, #quickMaxAmount, #quickTakeProfit, #quickStopLoss').forEach(input => {
            input.addEventListener('change', () => {
                this.syncQuickSettings();
            });
        });

        // Token filters
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.filterTokens(btn.dataset.filter);
            });
        });

        // Refresh tokens
        document.getElementById('refreshTokens').addEventListener('click', () => {
            this.refreshTokens();
        });

        // Chart period buttons
        document.querySelectorAll('.chart-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.updateChartPeriod(btn.dataset.period);
            });
        });

        // Theme selector
        document.getElementById('themeSelect').addEventListener('change', (e) => {
            this.changeTheme(e.target.value);
        });

        // Trading speed selector (add to settings)
        const tradingSpeedSelect = document.getElementById('tradingSpeed');
        if (tradingSpeedSelect) {
            tradingSpeedSelect.addEventListener('change', (e) => {
                this.setTradingSpeed(e.target.value);
            });
        }

        // Interface settings
        document.getElementById('autoRefresh').addEventListener('change', (e) => {
            // Handle auto refresh toggle
            console.log('Auto refresh:', e.target.checked);
        });

        document.getElementById('compactMode').addEventListener('change', (e) => {
            // Handle compact mode toggle
            document.body.classList.toggle('compact-mode', e.target.checked);
        });

        // Fullscreen button
        document.getElementById('fullscreenBtn').addEventListener('click', () => {
            this.toggleFullscreen();
        });

        // Refresh button
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.refreshTokens();
        });

        // Modal background click to close
        document.getElementById('walletModal').addEventListener('click', (e) => {
            if (e.target.classList.contains('wallet-modal')) {
                this.hideWalletModal();
            }
        });

        document.getElementById('settingsModal').addEventListener('click', (e) => {
            if (e.target.classList.contains('settings-modal')) {
                this.hideSettingsModal();
            }
        });
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.error('Error attempting to enable fullscreen:', err);
            });
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }
}

// Initialize the bot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.tradingBot = new EnhancedTradingBot();
});

// Handle fullscreen change
document.addEventListener('fullscreenchange', () => {
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    if (fullscreenBtn) {
        const icon = fullscreenBtn.querySelector('i');
        if (document.fullscreenElement) {
            icon.className = 'fas fa-compress';
            fullscreenBtn.title = 'Exit Fullscreen';
        } else {
            icon.className = 'fas fa-expand';
            fullscreenBtn.title = 'Toggle Fullscreen';
        }
    }
});