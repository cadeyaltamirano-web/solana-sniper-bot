// Trading Dashboard JavaScript

class TradingBot {
    constructor() {
        this.isConnected = false;
        this.walletAddress = null;
        this.walletBalance = 0;
        this.tokens = [];
        this.sessionId = 1;
        this.chart = null;
        this.stats = {
            totalTrades: 0,
            successfulTrades: 0,
            totalProfit: 0
        };
        
        this.init();
        this.startTokenSimulation();
        this.initChart();
        this.loadTheme();
        this.updateStats();
    }

    init() {
        this.bindEvents();
        this.updateUI();
        this.startStatusAnimation();
    }

    bindEvents() {
        // Wallet connection
        document.getElementById('walletConnectBtn').addEventListener('click', () => {
            if (!this.isConnected) {
                this.showWalletModal();
            } else {
                this.disconnectWallet();
            }
        });

        // Alternative connection
        document.getElementById('altConnectBtn').addEventListener('click', () => {
            this.connectAlternativeWallet();
        });

        // Modal controls
        document.getElementById('closeModal').addEventListener('click', () => {
            this.hideWalletModal();
        });

        // Wallet options
        document.querySelectorAll('.wallet-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const walletType = e.currentTarget.dataset.wallet;
                this.connectWallet(walletType);
            });
        });

        // Settings
        document.getElementById('settingsBtn').addEventListener('click', () => {
            this.showSettingsModal();
        });

        document.getElementById('closeSettingsModal').addEventListener('click', () => {
            this.hideSettingsModal();
        });

        document.getElementById('saveSettings').addEventListener('click', () => {
            this.saveSettings();
        });

        document.getElementById('cancelSettings').addEventListener('click', () => {
            this.hideSettingsModal();
        });

        // Stop bot
        document.getElementById('stopBtn').addEventListener('click', () => {
            this.stopBot();
        });

        // Refresh tokens
        document.getElementById('refreshTokens').addEventListener('click', () => {
            this.refreshTokens();
        });

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.filterTokens(e.target.dataset.filter);
            });
        });

        // Theme selector
        document.getElementById('themeSelect').addEventListener('change', (e) => {
            this.changeTheme(e.target.value);
        });

        // Auto refresh toggle
        document.getElementById('autoRefresh').addEventListener('change', (e) => {
            this.toggleAutoRefresh(e.target.checked);
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('wallet-modal')) {
                this.hideWalletModal();
            }
            if (e.target.classList.contains('settings-modal')) {
                this.hideSettingsModal();
            }
        });
    }

    // Wallet Connection Methods
    showWalletModal() {
        document.getElementById('walletModal').classList.add('active');
    }

    hideWalletModal() {
        document.getElementById('walletModal').classList.remove('active');
    }

    connectWallet(walletType) {
        const btn = document.getElementById('walletConnectBtn');
        btn.classList.add('connecting');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
        
        // Simulate connection delay
        setTimeout(() => {
            this.isConnected = true;
            this.walletAddress = this.generateWalletAddress();
            this.walletBalance = (Math.random() * 50 + 10).toFixed(2);
            
            this.updateUI();
            this.hideWalletModal();
            this.showNotification('Wallet connected successfully!', 'success');
            
            // Start trading simulation
            this.startTradingSimulation();
        }, 2000);
    }

    connectAlternativeWallet() {
        if (this.isConnected) {
            this.showNotification('Wallet already connected!', 'info');
            return;
        }

        const btn = document.getElementById('altConnectBtn');
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
        
        setTimeout(() => {
            this.isConnected = true;
            this.walletAddress = this.generateWalletAddress();
            this.walletBalance = (Math.random() * 30 + 5).toFixed(2);
            
            this.updateUI();
            btn.innerHTML = originalHTML;
            this.showNotification('Alternative connection established!', 'success');
            this.startTradingSimulation();
        }, 1500);
    }

    disconnectWallet() {
        this.isConnected = false;
        this.walletAddress = null;
        this.walletBalance = 0;
        this.updateUI();
        this.showNotification('Wallet disconnected', 'info');
    }

    generateWalletAddress() {
        const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
        let result = '';
        for (let i = 0; i < 44; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    // UI Update Methods
    updateUI() {
        const btn = document.getElementById('walletConnectBtn');
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        const walletInfo = document.getElementById('walletInfo');
        const walletAddress = document.getElementById('walletAddress');
        const walletBalance = document.getElementById('walletBalance');

        if (this.isConnected) {
            btn.classList.add('connected');
            btn.classList.remove('connecting');
            btn.innerHTML = '<i class="fas fa-wallet"></i> Connected';
            
            statusDot.classList.add('connected');
            statusText.textContent = 'CONNECTED';
            
            walletInfo.style.display = 'block';
            walletAddress.textContent = `${this.walletAddress.slice(0, 8)}...${this.walletAddress.slice(-8)}`;
            walletBalance.textContent = `${this.walletBalance} SOL`;
        } else {
            btn.classList.remove('connected', 'connecting');
            btn.innerHTML = '<i class="fas fa-wallet"></i> Connect Wallet';
            
            statusDot.classList.remove('connected');
            statusText.textContent = 'DISCONNECTED';
            
            walletInfo.style.display = 'none';
        }
    }

    // Token Simulation
    startTokenSimulation() {
        if (!this.autoRefreshEnabled) return;
        
        // Add new token every 3-8 seconds
        setInterval(() => {
            if (this.isConnected && this.autoRefreshEnabled) {
                this.addNewToken();
            }
        }, Math.random() * 5000 + 3000);
    }

    addNewToken() {
        const tokenNames = [
            'PEPE', 'DOGE', 'SHIB', 'MOON', 'SAFE', 'ROCKET', 'PUMP', 'GEM',
            'FIRE', 'BULL', 'BEAR', 'HODL', 'LAMBO', 'WAGMI', 'CHAD', 'KING', "CRACKER", "JUST COIN"
        ];
        
        const symbols = [
            'APE', 'BONK', 'WIF', 'BOME', 'SLERF', 'SMOL', 'MICHI', 'PONKE',
            'POPCAT', 'MYRO', 'JITO', 'JUP', 'RAY', 'ORCA', 'MNGO', 'SRM', "CRACK", "COIN"
        ];

        const token = {
            id: Date.now(),
            name: tokenNames[Math.floor(Math.random() * tokenNames.length)],
            symbol: symbols[Math.floor(Math.random() * symbols.length)],
            time: new Date().toLocaleTimeString(),
            status: 'seen',
            amount: '0.00 SOL',
            profit: 0,
            successRate: Math.floor(Math.random() * 100),
            icon: tokenNames[Math.floor(Math.random() * tokenNames.length)][0]
        };

        this.tokens.unshift(token);
        this.renderTokens();

        // Simulate trading after a delay
        setTimeout(() => {
            this.simulateTrading(token);
        }, Math.random() * 3000 + 1000);

        // Keep only last 20 tokens
        if (this.tokens.length > 20) {
            this.tokens = this.tokens.slice(0, 20);
        }
    }

    simulateTrading(token) {
        const actions = ['bought', 'sold'];
        const shouldTrade = Math.random() > 0.3; // 70% chance to trade
        
        if (!shouldTrade) return;

        // First, buy the token
        token.status = 'bought';
        token.amount = (Math.random() * 0.5 + 0.1).toFixed(2) + ' SOL';
        this.stats.totalTrades++;
        this.renderTokens();
        this.updateStats();

        // Then, possibly sell it
        setTimeout(() => {
            if (Math.random() > 0.4) { // 60% chance to sell
                token.status = 'sold';
                const isProfit = Math.random() > 0.35; // 65% success rate
                
                if (isProfit) {
                    token.profit = +(Math.random() * 2 + 0.1).toFixed(3);
                    this.stats.successfulTrades++;
                    this.stats.totalProfit += token.profit;
                } else {
                    token.profit = -(Math.random() * 1.5 + 0.05).toFixed(3);
                    this.stats.totalProfit += token.profit;
                }
                
                this.renderTokens();
                this.updateStats();
                this.updateChart();
            }
        }, Math.random() * 5000 + 2000);
    }

    renderTokens() {
        const tokenList = document.getElementById('tokenList');
        tokenList.innerHTML = '';

        this.tokens.forEach((token, index) => {
            const tokenElement = document.createElement('div');
            tokenElement.className = 'token-item';
            tokenElement.style.animationDelay = `${index * 0.1}s`;
            
            const profitClass = token.profit > 0 ? 'positive' : token.profit < 0 ? 'negative' : '';
            const profitText = token.profit !== 0 ? 
                `${token.profit > 0 ? '+' : ''}${token.profit} SOL` : '0.00 SOL';

            tokenElement.innerHTML = `
                <div class="token-info">
                    <div class="token-icon">${token.icon}</div>
                    <div class="token-details">
                        <span class="token-name">${token.name}</span>
                        <span class="token-symbol">${token.symbol}</span>
                    </div>
                </div>
                <div class="token-time">${token.time}</div>
                <div class="token-status">
                    <span class="status-badge ${token.status}">${token.status.toUpperCase()}</span>
                </div>
                <div class="token-amount">${token.amount}</div>
                <div class="token-profit ${profitClass}">${profitText}</div>
                <div class="token-success-rate">${token.successRate}%</div>
                <div class="token-actions">
                    <button class="action-btn view" title="View Details">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${token.status === 'bought' ? 
                        '<button class="action-btn sell" title="Force Sell"><i class="fas fa-times"></i></button>' : 
                        ''
                    }
                </div>
            `;

            tokenList.appendChild(tokenElement);
        });
    }

    filterTokens(filter) {
        const tokenItems = document.querySelectorAll('.token-item');
        
        tokenItems.forEach(item => {
            const profitElement = item.querySelector('.token-profit');
            const isProfit = profitElement.classList.contains('positive');
            const isLoss = profitElement.classList.contains('negative');
            
            let show = true;
            
            switch(filter) {
                case 'profitable':
                    show = isProfit;
                    break;
                case 'losses':
                    show = isLoss;
                    break;
                case 'all':
                default:
                    show = true;
                    break;
            }
            
            item.style.display = show ? 'grid' : 'none';
        });
    }

    refreshTokens() {
        const btn = document.getElementById('refreshTokens');
        btn.style.transform = 'rotate(180deg) scale(1.1)';
        
        setTimeout(() => {
            btn.style.transform = '';
            this.showNotification('Token list refreshed', 'info');
            
            // Add a few new tokens
            for (let i = 0; i < 3; i++) {
                setTimeout(() => this.addNewToken(), i * 500);
            }
        }, 500);
    }

    // Stats and Chart
    updateStats() {
        document.getElementById('totalTrades').textContent = this.stats.totalTrades;
        document.getElementById('successfulTrades').textContent = this.stats.successfulTrades;
        
        const winRate = this.stats.totalTrades > 0 ? 
            Math.round((this.stats.successfulTrades / this.stats.totalTrades) * 100) : 0;
        document.getElementById('winRate').textContent = `${winRate}%`;
        document.getElementById('totalProfit').textContent = `${this.stats.totalProfit.toFixed(3)} SOL`;
    }

    initChart() {
        const ctx = document.getElementById('profitChart').getContext('2d');
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Profit/Loss',
                    data: [],
                    borderColor: '#00ff88',
                    backgroundColor: 'rgba(0, 255, 136, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        display: false,
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        display: false,
                        grid: {
                            display: false
                        }
                    }
                },
                elements: {
                    point: {
                        radius: 0
                    }
                }
            }
        });

        // Initialize with some data
        for (let i = 0; i < 10; i++) {
            this.chart.data.labels.push('');
            this.chart.data.datasets[0].data.push(Math.random() * 4 - 2);
        }
        this.chart.update();
    }

    updateChart() {
        if (!this.chart) return;
        
        const data = this.chart.data.datasets[0].data;
        const newValue = this.stats.totalProfit || (Math.random() * 4 - 2);
        
        data.push(newValue);
        this.chart.data.labels.push('');
        
        if (data.length > 20) {
            data.shift();
            this.chart.data.labels.shift();
        }
        
        this.chart.update('none');
    }

    // Settings
    showSettingsModal() {
        document.getElementById('settingsModal').classList.add('active');
        this.loadCurrentSettings();
    }

    hideSettingsModal() {
        document.getElementById('settingsModal').classList.remove('active');
    }

    loadCurrentSettings() {
        const saved = localStorage.getItem('botSettings');
        if (saved) {
            const settings = JSON.parse(saved);
            document.getElementById('settingsMinAmount').value = settings.minAmount || '0.1';
            document.getElementById('settingsMaxAmount').value = settings.maxAmount || '1.0';
            document.getElementById('settingsSlippage').value = settings.slippage || '5';
            document.getElementById('settingsTakeProfit').value = settings.takeProfit || '50';
            document.getElementById('settingsStopLoss').value = settings.stopLoss || '30';
            document.getElementById('settingsMaxDevHold').value = settings.maxDevHold || '30';
        }
    }

    saveSettings() {
        const settings = {
            minAmount: document.getElementById('settingsMinAmount').value,
            maxAmount: document.getElementById('settingsMaxAmount').value,
            slippage: document.getElementById('settingsSlippage').value,
            takeProfit: document.getElementById('settingsTakeProfit').value,
            stopLoss: document.getElementById('settingsStopLoss').value,
            maxDevHold: document.getElementById('settingsMaxDevHold').value
        };

        localStorage.setItem('botSettings', JSON.stringify(settings));
        this.hideSettingsModal();
        this.showNotification('Settings saved successfully!', 'success');
    }

    // Theme Management
    loadTheme() {
        const savedTheme = localStorage.getItem('selectedTheme') || 'theme1';
        this.changeTheme(savedTheme);
        document.getElementById('themeSelect').value = savedTheme;
    }

    changeTheme(themeName) {
        document.documentElement.className = themeName;
        localStorage.setItem('selectedTheme', themeName);
        this.showNotification(`Theme changed to ${themeName}`, 'info');
    }

    // Auto Refresh
    toggleAutoRefresh(enabled) {
        this.autoRefreshEnabled = enabled;
        localStorage.setItem('autoRefresh', enabled);
        
        if (enabled) {
            this.showNotification('Auto refresh enabled', 'success');
        } else {
            this.showNotification('Auto refresh disabled', 'info');
        }
    }

    // Misc Methods
    startStatusAnimation() {
        const statusDot = document.getElementById('statusDot');
        const sessionNumber = document.getElementById('sessionNumber');
        
        // Animate session number periodically
        setInterval(() => {
            if (this.isConnected) {
                this.sessionId++;
                sessionNumber.textContent = this.sessionId;
            }
        }, 30000); // Every 30 seconds
    }

    startTradingSimulation() {
        // Start more aggressive token generation when connected
        this.autoRefreshEnabled = true;
        
        // Add some initial tokens
        setTimeout(() => {
            for (let i = 0; i < 5; i++) {
                setTimeout(() => this.addNewToken(), i * 1000);
            }
        }, 1000);
    }

    stopBot() {
        this.showNotification('Bot stopped', 'warning');
        this.autoRefreshEnabled = false;
        
        // Update UI to show stopped state
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        
        statusDot.classList.add('error');
        statusText.textContent = 'STOPPED';
        
        setTimeout(() => {
            statusDot.classList.remove('error');
            if (this.isConnected) {
                statusDot.classList.add('connected');
                statusText.textContent = 'CONNECTED';
            }
            this.autoRefreshEnabled = true;
        }, 5000);
    }

    // Notification System
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 
                              type === 'error' ? 'fa-exclamation-circle' : 
                              type === 'warning' ? 'fa-exclamation-triangle' :
                              'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        // Add notification styles if not already present
        if (!document.getElementById('notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: var(--surface);
                    border: 1px solid var(--border);
                    border-radius: var(--radius-md);
                    padding: var(--space-md);
                    box-shadow: var(--shadow-xl);
                    z-index: 10000;
                    animation: slideInRight 0.3s ease;
                    max-width: 300px;
                    backdrop-filter: blur(20px);
                }
                .notification-success {
                    border-left: 4px solid var(--success);
                }
                .notification-error {
                    border-left: 4px solid var(--error);
                }
                .notification-warning {
                    border-left: 4px solid var(--warning);
                }
                .notification-info {
                    border-left: 4px solid var(--primary);
                }
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: var(--space-sm);
                    color: var(--text-primary);
                    font-size: 0.875rem;
                }
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                @keyframes slideOutRight {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize the trading bot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new TradingBot();
});

// Add some theme variables for different themes
const themes = {
    theme1: {
        '--primary': '#00ff88',
        '--background': '#0a0a0f',
        '--surface': '#1a1a24'
    },
    theme2: {
        '--primary': '#39ff14',
        '--background': '#0d1117',
        '--surface': '#161b22'
    },
    theme3: {
        '--primary': '#8b5cf6',
        '--background': '#0f0a1a',
        '--surface': '#1e1b3a'
    },
    theme4: {
        '--primary': '#fbbf24',
        '--background': '#1a1400',
        '--surface': '#2d2817'
    },
    theme5: {
        '--primary': '#ef4444',
        '--background': '#1a0a0a',
        '--surface': '#2d1b1b'
    },
    theme6: {
        '--primary': '#06b6d4',
        '--background': '#0a1419',
        '--surface': '#1b2d35'
    },
    theme7: {
        '--primary': '#10b981',
        '--background': '#0a1914',
        '--surface': '#1b352d'
    },
    theme8: {
        '--primary': '#f97316',
        '--background': '#1a0f0a',
        '--surface': '#2d1f1b'
    }
};

// Apply theme when theme class is added to html
function applyTheme(themeName) {
    if (themes[themeName]) {
        const root = document.documentElement;
        Object.keys(themes[themeName]).forEach(property => {
            root.style.setProperty(property, themes[themeName][property]);
        });
    }
}