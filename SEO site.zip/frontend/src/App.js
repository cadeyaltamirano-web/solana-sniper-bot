import { useEffect } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import axios from "axios";
import TradingDashboard from "./TradingDashboard";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Home = () => {
  const helloWorldApi = async () => {
    try {
      const response = await axios.get(`${API}/`);
      console.log(response.data.message);
    } catch (e) {
      console.error(e, `errored out requesting / api`);
    }
  };

  useEffect(() => {
    helloWorldApi();
  }, []);

  return (
    <div>
      <header className="App-header">
        <a
          className="App-link"
          href="https://emergent.sh"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img src="https://avatars.githubusercontent.com/in/1201222?s=120&u=2686cf91179bbafbc7a71bfbc43004cf9ae1acea&v=4" alt="Emergent Logo" />
        </a>
        <p className="mt-5">PumpFun Sniper Bot - Real-time Trading Dashboard</p>
        
        {/* Navigation to Trading Dashboard */}
        <div style={{ marginTop: '30px' }}>
          <Link 
            to="/trading" 
            style={{
              display: 'inline-block',
              padding: '15px 30px',
              backgroundColor: '#00ff88',
              color: '#000',
              textDecoration: 'none',
              borderRadius: '8px',
              fontWeight: 'bold',
              fontSize: '18px',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#00cc6a';
              e.target.style.transform = 'scale(1.05)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#00ff88';
              e.target.style.transform = 'scale(1)';
            }}
          >
            🚀 Launch Trading Dashboard
          </Link>
        </div>
        
        {/* Direct link to HTML version */}
        <div style={{ marginTop: '15px' }}>
          <a 
            href="/trading/vipdetect.html"
            style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#333',
              color: '#fff',
              textDecoration: 'none',
              borderRadius: '5px',
              fontSize: '14px'
            }}
          >
            📊 Direct Dashboard Access
          </a>
        </div>
        
        <div style={{ marginTop: '30px', maxWidth: '600px', textAlign: 'left' }}>
          <h3 style={{ color: '#00ff88' }}>Features:</h3>
          <ul style={{ fontSize: '14px', lineHeight: '1.6' }}>
            <li>✅ Real-time token detection from Pump.fun</li>
            <li>✅ WebSocket streaming for instant updates</li>
            <li>✅ Advanced trading bot with AI features</li>
            <li>✅ Multiple trading speeds (Fast: 2s, Normal: 5s, Conservative: 15s)</li>
            <li>✅ Wallet integration simulation</li>
            <li>✅ Honeypot and rug pull detection</li>
            <li>✅ Real-time statistics and profit tracking</li>
            <li>✅ 8 different UI themes</li>
          </ul>
        </div>
      </header>
    </div>
  );
};

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/trading" element={<TradingDashboard />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
