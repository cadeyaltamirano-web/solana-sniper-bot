import { useEffect } from 'react';

const TradingDashboard = () => {
  useEffect(() => {
    // Redirect to the actual trading dashboard HTML file
    window.location.href = '/trading/vipdetect.html';
  }, []);

  // Show loading while redirecting
  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      flexDirection: 'column',
      backgroundColor: '#0a0a0a',
      color: '#fff'
    }}>
      <div style={{ marginBottom: '20px' }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #333',
          borderTop: '4px solid #00ff88',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
      <h2>Loading PumpFun Sniper Bot...</h2>
      <p>Redirecting to trading dashboard...</p>
      
      <style jsx>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default TradingDashboard;